math.randomseed ( os.time () )
